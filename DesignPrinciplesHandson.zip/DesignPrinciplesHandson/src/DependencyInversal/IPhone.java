package DependencyInversal;

public interface IPhone {

	public String getPhonePart1();
	
	public double getPart1Cost();
}
