package abstractFactoryPattern;

public class AudiHeadLight extends HeadLight {

	public AudiHeadLight() {
		super("Audi HeadLight");
	}

}
