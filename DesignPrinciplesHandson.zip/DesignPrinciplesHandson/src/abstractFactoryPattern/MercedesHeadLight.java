package abstractFactoryPattern;

public class MercedesHeadLight extends HeadLight {

	public MercedesHeadLight() {
		super("Mercedes HeadLight");
	}

}
