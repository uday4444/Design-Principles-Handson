package SampleApplication;

public interface IOrderRepair {

	void processOrder(String modelName);

	void processPhoneRepair(String modelName);

	void processAccessoryRepair(String accessoryType);

}
